//
//  ViewController.swift
//  1._Adding_numbers
//
//  Created by 杨卢青 on 16/8/8.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import Foundation
import UIKit
import RxSwift
import RxCocoa

class ViewController: UIViewController {
  @IBOutlet weak var number1: UITextField!
  @IBOutlet weak var number2: UITextField!
  @IBOutlet weak var number3: UITextField!
  @IBOutlet weak var result: UILabel!

  var disposeBag = DisposeBag()

  override func viewDidLoad() {
    super.viewDidLoad()

    /**
     *
     combineLatest :
     当序列中的任何一个发射了数据时，combineLatest 会结合并整理每个序列发射的最近数据项。

     map :
     一个一个的改变里面的值，并返回一个新的 functor 。

     bindTo:
     创建一个新的订阅，并且把observable发射来的数据传递给observer,
     这里result的rx_text是一个observer。
     即将新数据绑定到result的rx_text上。

     DisposeBag :
     订阅时，当使用完一个数据序列时，需要释放掉它们所分配的资源，不然很耗内存，我们可以对每个订阅调用dispose()
     */
    Observable.combineLatest(number1.rx_text, number2.rx_text, number3.rx_text) { textValue1, textValue2, textValue3 -> Int in
      return (Int(textValue1) ?? 0) + (Int(textValue2) ?? 0) + (Int(textValue3) ?? 0)
    }
      .map { $0.description }
      .bindTo(result.rx_text)
      .addDisposableTo(disposeBag)

  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }

}

