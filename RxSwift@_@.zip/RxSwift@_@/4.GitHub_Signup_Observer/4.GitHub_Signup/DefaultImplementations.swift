//
//  DefaultImplementations.swift
//  4.GitHub_Signup
//
//  Created by 杨卢青 on 16/8/10.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import Foundation
#if !RX_NO_MODULE
  import RxSwift
#endif

class GitHubDefaultValidationService: GitHubValidationService {
  let API: GitHubAPI

  static let sharedValidationServeice = GitHubDefaultValidationService(API: GitHubDefaultAPI.sharedAPI)

  init (API: GitHubAPI) {
    self.API = API
  }

  // MARK: validation

  let minPasswordCount = 5

  func validateUsername(username: String) -> Observable<ValidationResult> {

    // 如果没写, 就返回一个空队列
    if username.characters.count == 0 {
      return Observable.just(.Empty)
    }

    // this obviously won't be 😓
    if username.rangeOfCharacterFromSet(NSCharacterSet.alphanumericCharacterSet().invertedSet) != nil {
      return Observable.just(.Failed(message: "Username can only contain numbers or digits"))
    }

    let loadingValue = ValidationResult.Validating

    return API
      .usernameAvailable(username)
      .map { available in
        if available {
          return .OK(message: "Username available")
        }
        else {
          return .Failed(message: "Username already taken")
        }
    }
      .startWith(loadingValue)
  }
  func validatePassword(password: String) -> ValidationResult {
    let numberOfCharacters = password.characters.count
    if numberOfCharacters == 0 {
      return .Empty
    }
    if numberOfCharacters < minPasswordCount {
      return .Failed(message: "Password must be at least \(minPasswordCount) characters")
    }
    return .OK(message: "Password acceptable")
  }
  func validateRepeatePassword(password: String, repeatedPassword: String) -> ValidationResult {

    if repeatedPassword.characters.count == 0 {
      return .Empty
    }

    if repeatedPassword == password {
      return .OK(message: "Password repeated")
    }
    else {
      return .Failed(message: "Password different")
    }
  }
}

class GitHubDefaultAPI: GitHubAPI {
  let URLSession: NSURLSession

  static let sharedAPI = GitHubDefaultAPI(
    URLSession: NSURLSession.sharedSession()
  )

  init(URLSession: NSURLSession) {
    self.URLSession = URLSession
  }

  func usernameAvailable(username: String) -> Observable<Bool> {
    // this is ofc just mock, but good enough

    let URL = NSURL(string: "https://github.com/\(username.URLEscaped)")!
    print("URL:\n", URL)
    let request = NSURLRequest(URL: URL)
    return self.URLSession.rx_response(request)
      .map { (maybeData, reponse) in
        return reponse.statusCode == 404
    }
      .catchErrorJustReturn(false)

  }

  func signup(username: String, password: String) -> Observable<Bool> {
    // this is also just a mock 👻
    let signupResult = arc4random() % 5 == 0 ? false : true

    // concat  串行合并多个序列(第一个序列发送完发送第二个序列) 与switch不同的是不会抛弃任何一个序列
    // never() 不创建序列，也不发送通知
    return Observable.just(signupResult)
      .concat(Observable.never())
      .throttle(0.4, scheduler: MainScheduler.instance)
      .take(1) // 只发射指定数量的值(前几个值)。
  }
}
