//
//  GitHubSignupViewController1.swift
//  4.GitHub_Signup
//
//  Created by 杨卢青 on 16/8/10.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import UIKit
import Foundation
import RxSwift
import RxCocoa

class GitHubSignupViewController1: UIViewController {

  @IBOutlet weak var usernameTextField: UITextField!
  @IBOutlet weak var passwordTextField: UITextField!

  @IBOutlet weak var passwordRepeatTextField: UITextField!

  @IBOutlet weak var usernameValidLabel: UILabel!

  @IBOutlet weak var passwordValidLabel: UILabel!

  @IBOutlet weak var passwordRepeatValidLabel: UILabel!

  @IBOutlet weak var signUpButton: UIButton!

  @IBOutlet weak var activityIndicator: UIActivityIndicatorView!

  var disposeBag = DisposeBag()
  // MARK: life cycle
  override func viewDidLoad() {
    let viewModel = GithubSignupViewModel1(
      input: (
        username: usernameTextField.rx_text.asObservable(),
        password: passwordTextField.rx_text.asObservable(),
        repeatedPassword: passwordRepeatTextField.rx_text.asObservable(),
        loginTaps: signUpButton.rx_tap.asObservable()
      ),
      dependency: (
        API: GitHubDefaultAPI.sharedAPI,
        validationService: GitHubDefaultValidationService.sharedValidationServeice,
        wireframe: DefaultWireframe.sharedInstance
      )
    )

    // bind result to
    viewModel.signupEnabled
      .subscribeNext { [weak self] valid in
        self?.signUpButton.enabled = valid
        self?.signUpButton.alpha = valid ? 1.0 : 0.5
    }
      .addDisposableTo(disposeBag)

    viewModel.validatedUsername
      .bindTo(usernameValidLabel.ex_validationResult)
      .addDisposableTo(disposeBag)

    viewModel.validatedPassword
      .bindTo(passwordValidLabel.ex_validationResult)
      .addDisposableTo(disposeBag)

    viewModel.validatedPasswordRepeated
      .bindTo(passwordRepeatValidLabel.ex_validationResult)
      .addDisposableTo(disposeBag)

    viewModel.signingIn
      .bindTo(activityIndicator.rx_animating)
      .addDisposableTo(disposeBag)

    // 如果没有这一段, signedIn序列就不会开始
    viewModel.signedIn
      .subscribeNext {
        signedIn in
        print("User signed in \(signedIn)")
    }
      .addDisposableTo(disposeBag)

    // 点击view结束编辑, keyboard退出
    let tapBackground = UITapGestureRecognizer()
    tapBackground.rx_event
      .subscribeNext { [weak self] _ in
        self?.view.endEditing(true)
    }
      .addDisposableTo(disposeBag)
    view.addGestureRecognizer(tapBackground)
  }

  override func willMoveToParentViewController(parent: UIViewController?) {
    if let parent = parent {
      assert(parent.isKindOfClass(UINavigationController), "Please read comments")
    }
    else {
      self.disposeBag = DisposeBag()
    }
  }
}
