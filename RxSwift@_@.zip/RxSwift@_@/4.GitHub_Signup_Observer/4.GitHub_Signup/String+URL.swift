//
//  String+URL.swift
//  4.GitHub_Signup
//
//  Created by 杨卢青 on 16/8/10.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import Foundation

extension String {
  var URLEscaped: String {
    return self.stringByAddingPercentEncodingWithAllowedCharacters(.URLHostAllowedCharacterSet()) ?? ""
  }
}
