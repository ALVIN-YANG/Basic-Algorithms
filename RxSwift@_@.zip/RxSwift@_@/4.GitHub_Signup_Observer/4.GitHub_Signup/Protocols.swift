//
//  Protocols.swift
//  4.GitHub_Signup
//
//  Created by 杨卢青 on 16/8/10.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import Foundation
#if !RX_NO_MODULE
  import RxSwift
  import RxCocoa
#endif

enum ValidationResult {
  case OK(message: String)
  case Empty
  case Validating
  case Failed(message: String)
}

extension ValidationResult {
  var isValid: Bool {
    switch self {
    case .OK:
      return true
    default:
      return false
    }
  }
}

enum SignupState {
  case SignedUp(signedUp: Bool)
}

protocol GitHubAPI {
  func usernameAvailable(username: String) -> Observable<Bool>
  func signup(username: String, password: String) -> Observable<Bool>
}

protocol GitHubValidationService {
  func validateUsername(username: String) -> Observable<ValidationResult>
  func validatePassword(password: String) -> ValidationResult
  func validateRepeatePassword(password: String, repeatedPassword: String) -> ValidationResult
}

