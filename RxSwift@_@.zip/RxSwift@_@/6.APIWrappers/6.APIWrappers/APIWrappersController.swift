//
//  ViewController.swift
//  6.APIWrappers
//
//  Created by 杨卢青 on 16/8/15.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import UIKit
import CoreLocation
import RxSwift
import RxCocoa

extension UILabel {
  public override var accessibilityValue: String? {
    get {
      return self.text
    }
    set {
      self.text = newValue
      // TODO: 这里为什么不会造成循环引用
      self.accessibilityValue = newValue
    }
  }
}

class APIWrappersController: UIViewController {

  @IBOutlet weak var degbugLabel: UILabel!
  @IBOutlet weak var openActionSheetButton: UIButton!

  @IBOutlet weak var openAlertViewButton: UIButton!

  @IBOutlet weak var segmentButton: UISegmentedControl!

  @IBOutlet weak var switchButton: UISwitch!

  @IBOutlet weak var tapButton: UIButton!

  @IBOutlet weak var textField: UITextField!

  @IBOutlet weak var HorizontalSlider: UISlider!

  @IBOutlet weak var datePicker: UIDatePicker!

  @IBOutlet weak var activityIndicator: UIActivityIndicatorView!

  @IBOutlet var myPan: UIPanGestureRecognizer!

  @IBOutlet weak var textView: UITextView!
	
	let locationManager = CLLocationManager()

	var disposeBag = DisposeBag()
	
  override func viewDidLoad() {
    super.viewDidLoad()

    datePicker.date = NSDate(timeIntervalSince1970: 0)

    // MARK:- UISegmentedControl
    // also test two way binding
    let segmentedValue = Variable(0)
    segmentButton.rx_value <-> segmentedValue
		
		segmentedValue.asObservable()
			.subscribeNext { [weak self] x in
				self?.debug("UISegmentControl value \(x)")
		}
		.addDisposableTo(disposeBag)

		// MARK:- UISwitch
		
		// also test two way binding
		let switchValue = Variable(true)
		switchButton.rx_value <-> switchValue
		
		switchValue.asObservable()
			.subscribeNext { [weak self] x in
				self?.debug("UISwitch value \(x)")
		}
		.addDisposableTo(disposeBag)
		
		// MARK:- UIActivityIndicatorView
		switchButton.rx_value
			.bindTo(activityIndicator.rx_animating)
			.addDisposableTo(disposeBag)
		
		// MARK:- UIButton
		
		tapButton.rx_tap
			.subscribeNext { [weak self] x in
				self?.debug("UIButton Tapped")
		}
		.addDisposableTo(disposeBag)
		
		
		// MARK:- UISlider
		// also test two way binding
		let sliderValue = Variable<Float>(1.0)
		HorizontalSlider.rx_value <-> sliderValue
		
		sliderValue.asObservable()
			.subscribeNext { [weak self] x in
				self?.debug("UISlider value \(x)")
		}
		.addDisposableTo(disposeBag)
		
		// MARK:- UIDatePicker
		// also test two way binding
		let dateValue = Variable(NSDate(timeIntervalSince1970: 0))
		datePicker.rx_date <-> dateValue
		
		dateValue.asObservable()
			.subscribeNext { [weak self] x in
				self?.debug("UIDatePicker date \(x)")
		}
		.addDisposableTo(disposeBag)
		
		// MARK:- UITextField
		// also test two way binding
		let textValue = Variable("")
		textField.layer.borderWidth = 1
		textField.layer.borderColor = UIColor.lightGrayColor().CGColor
		textField <-> textValue
		
		textValue.asObservable()
			.subscribeNext { [weak self] x in
				self?.debug("UITextField text \(x)")
		}
		.addDisposableTo(disposeBag)
		
		// MARK:- UIGestureRecognizer
		myPan.rx_event
			.subscribeNext { [weak self] x in
				self?.debug(" \(x.state)")
		}
		.addDisposableTo(disposeBag)
		
		// MARK:- UITextView
		// also test two way binding
		let textViewValue = Variable("")
		textView.layer.borderWidth = 1
		textView.layer.borderColor = UIColor.lightGrayColor().CGColor
		textView.layer.cornerRadius = 10
		textView.clipsToBounds = true
		textView <-> textViewValue
		
		textViewValue.asObservable()
			.subscribeNext { [weak self] x in
				self?.debug("UITextView text \(x)")
		}
		.addDisposableTo(disposeBag)
		
		// MARK:- CLLocationManager
		locationManager.requestWhenInUseAuthorization()
		
		locationManager.rx_didUpdateLocations
			.subscribeNext { x in
				print("rx_didUpdateLocations \(x)")
		}
		.addDisposableTo(disposeBag)
		
		_ = locationManager.rx_didFailWithError
			.subscribeNext { x in
				print("rx_didFailWithError \(x)")
		}
		
		locationManager.rx_didChangeAuthorizationStatus
			.subscribeNext { status in
				print("Authorization status \(status)")
		}
		.addDisposableTo(disposeBag)
		
		locationManager.startUpdatingLocation()
		
		
		// MARK:- openActionSheetButton
		openActionSheetButton.rx_tap
			.subscribeNext {
				let actionSheet = UIActionSheet.init(title: "Action Sheet", delegate: nil, cancelButtonTitle: "cancle", destructiveButtonTitle: "取消")
				actionSheet.showInView(self.view)
		}
		.addDisposableTo(disposeBag)
		
	
		// MARK:- openAlertViewButton
		openAlertViewButton.rx_tap
			.subscribeNext { [weak self] in
				self?.debug("tapedOpenActionSheetButton")
				let alertView = UIAlertController()
				let action = UIAlertAction.init(title: "open action sheet", style: .Default, handler: nil)
				let action1 = UIAlertAction.init(title: "cancel", style: .Destructive, handler: nil)
				alertView.addAction(action)
				alertView.addAction(action1)
				self?.presentViewController(alertView, animated: true, completion: nil)
			}
			.addDisposableTo(disposeBag)
  }
	
	func debug(string: String) {
		print(string)
		degbugLabel.text = string
	}

}

