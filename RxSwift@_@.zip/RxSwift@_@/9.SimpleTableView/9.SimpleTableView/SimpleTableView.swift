//
//  SimpleTableView.swift
//  9.SimpleTableView
//
//  Created by 杨卢青 on 16/8/18.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import UIKit
import Foundation
import RxSwift
import RxCocoa

class SimpleTableView: UIViewController {
	@IBOutlet weak var tableView: UITableView!
	
	let disposeBag = DisposeBag()

	override func viewDidLoad() {
		super.viewDidLoad()
		
		let items = Observable.just([
																	"First Item",
																	"Second Item",
																	"Third Item"
																])
		items
			.bindTo(tableView.rx_itemsWithCellIdentifier("Cell", cellType: UITableViewCell.self)) { (row, element, cell) in
				cell.textLabel?.text = "\(element) @ row \(row)"
		}
		.addDisposableTo(disposeBag)
		
		tableView
			.rx_modelSelected(String)
			.subscribeNext { value in
				DefaultWireframe.presentAlert("Tapped `\(value)`")
		}
		.addDisposableTo(disposeBag)
		
//		tableView
//			.rx_itemAccessoryButtonTapped
//			.subscribeNext { indexPath in
//				DefaultWireframe.presentAlert("Tapped Detail @\(indexPath.section), \(indexPath.row)")
//		}
//		.addDisposableTo(disposeBag)
	}
}
