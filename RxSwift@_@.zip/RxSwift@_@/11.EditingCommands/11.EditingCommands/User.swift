//
//  User.swift
//  11.EditingCommands
//
//  Created by 杨卢青 on 16/8/19.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import Foundation

// MARK:- 重定义 `==` 与 `debugDescription`
// 全局的struct 协议的实现写在哪个文件都行
struct User: Equatable, CustomDebugStringConvertible {
	var firstName: String
	var lastName: String
	var imageURL: String
	
	init(firstName: String, lastName: String, imageURL: String) {
		self.firstName = firstName
		self.lastName = lastName
		self.imageURL = imageURL
	}
}

extension User {
	var debugDescription: String {
		return firstName + " " + lastName
	}
}

func ==(lhs: User, rhs: User) -> Bool {
	return lhs.firstName == rhs.firstName &&
		lhs.lastName == rhs.lastName &&
		lhs.imageURL == rhs.imageURL
}




