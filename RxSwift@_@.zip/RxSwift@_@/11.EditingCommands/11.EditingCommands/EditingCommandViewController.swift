//
//  EditingCommandViewController.swift
//  11.EditingCommands
//
//  Created by 杨卢青 on 16/8/19.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import UIKit
import Foundation
import RxSwift
import RxCocoa

class EditingCommandViewController: UIViewController {

	let array = [1, 1, 1, 1, 2, 3, 1, 1, 4, 5, 1]
	
	let disposeBag = DisposeBag()
	override func viewDidLoad() {
		array.toObservable()
			.distinctUntilChanged()
			.bindNext { (item) in
				print(item, " ")
		}
		.addDisposableTo(disposeBag)
	}
}
