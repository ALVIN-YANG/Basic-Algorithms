//
//  UIImageView+Cycle.swift
//  11.EditingCommands
//
//  Created by 杨卢青 on 16/8/19.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import UIKit

extension UIImageView {
	func makeRoundedCorners(radius: CGFloat) {
		self.layer.cornerRadius = self.frame.size.width / 2
		self.layer.borderColor = UIColor.darkGrayColor().CGColor
		self.layer.borderWidth = radius
		self.layer.masksToBounds = true
	}
}


