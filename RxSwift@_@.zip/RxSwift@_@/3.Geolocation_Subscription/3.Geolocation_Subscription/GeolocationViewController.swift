//
//  GeolocationViewController.swift
//  3.Geolocation_Subscription
//
//  Created by 杨卢青 on 16/8/9.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import UIKit
import CoreLocation
import RxSwift
import RxCocoa

private extension UILabel {
  var rx_driveCoordinates: AnyObserver<CLLocationCoordinate2D> {
    return UIBindingObserver(UIElement: self) { label, location in
      label.text = "Lat: \(location.latitude)\nLon: \(location.longitude)"
    }.asObserver()
  }
}

private extension UIView {
  var rx_driveAuthorization: AnyObserver<Bool> {
    return UIBindingObserver(UIElement: self) { view, authorized in
      if authorized {
        view.hidden = true
        view.superview?.sendSubviewToBack(view)
      }
      else {
        view.hidden = false
        view.superview?.bringSubviewToFront(view)
      }
    }.asObserver()
  }
}

class GeolocationViewController: UIViewController {

  @IBOutlet weak var noGeolocationView: UIView!

  @IBOutlet weak var openPreferences: UIButton!

  @IBOutlet weak var openPreferenceEnabled: UIButton!

  @IBOutlet weak var label: UILabel!

  var disposeBag = DisposeBag()

  override func viewDidLoad() {
    super.viewDidLoad()

    let geolocationService = GeolocationService.instance

    geolocationService.authorized
      .drive(noGeolocationView.rx_driveAuthorization)
      .addDisposableTo(disposeBag)

    geolocationService.location
      .drive(label.rx_driveCoordinates)
      .addDisposableTo(disposeBag)

    geolocationService.location
      .drive(label.rx_driveCoordinates)
      .addDisposableTo(disposeBag)

    openPreferences.rx_tap
      .bindNext {
        self.openAppPreferences()
    }
      .addDisposableTo(disposeBag)

    openPreferenceEnabled.rx_tap
      .bindNext {
        self.openAppPreferences()
    }
      .addDisposableTo(disposeBag)

  }

  private func openAppPreferences() {
    UIApplication.sharedApplication().openURL(NSURL(string: UIApplicationOpenSettingsURLString)!)
  }
}

