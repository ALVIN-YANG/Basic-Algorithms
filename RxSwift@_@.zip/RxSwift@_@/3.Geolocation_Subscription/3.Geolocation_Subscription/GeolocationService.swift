//
//  GeolocationService.swift
//  3.Geolocation_Subscription
//
//  Created by 杨卢青 on 16/8/9.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import Foundation
import CoreLocation
import RxSwift
import RxCocoa

class GeolocationService {

  static let instance = GeolocationService()
  private (set) var authorized: Driver<Bool>
  // (set) 访问级别设置:只有在当前源文件中可以执行写操作
  private (set) var location: Driver<CLLocationCoordinate2D>

  private let locationManager = CLLocationManager()

  private init() {
    // 它的单位是米，设为kCLDistanceFilterNone，则每秒更新一次
    locationManager.distanceFilter = kCLDistanceFilterNone
    // 导航情况下最高精度, 挺费电的
    locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation

    // deferred 只有在有观察者订阅时，才去创建序列
    authorized = Observable.deferred { [weak locationManager] in
      let status = CLLocationManager.authorizationStatus()
      guard let locationManager = locationManager else {
        return Observable.just(status)
        // just 只创建包含一个元素的序列。换言之，只发送一个值和 .Completed
      }
      return locationManager
        .rx_didChangeAuthorizationStatus
        .startWith(status)
      // startWith 在序列前插入一个值
    }
      .asDriver(onErrorJustReturn: CLAuthorizationStatus.NotDetermined)
      .map {
        switch $0 {
        case .AuthorizedAlways:
          return true
        default:
          return false
        }
    }
    location = locationManager.rx_didUpdateLocations
      .asDriver(onErrorJustReturn: [])
      .flatMap {
        // 将一个序列发射的值转换成序列，然后将他们压平到一个序列里面。 类似二阶
        return $0.last.map(Driver.just) ?? Driver.empty()
    }
      .map { $0.coordinate }
		//返回坐标

    locationManager.requestAlwaysAuthorization()
    locationManager.startUpdatingLocation()
  }
}
