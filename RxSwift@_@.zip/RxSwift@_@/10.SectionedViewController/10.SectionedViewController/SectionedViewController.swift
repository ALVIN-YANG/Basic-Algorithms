//
//  SectionedViewController.swift
//  10.SectionedViewController
//
//  Created by 杨卢青 on 16/8/18.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import UIKit
import Foundation
import RxDataSources
import RxSwift
import RxCocoa

class SectionedViewController: UIViewController, UITableViewDelegate {
	@IBOutlet weak var tableView: UITableView!

	let disposeBag = DisposeBag()
	let dataSource = RxTableViewSectionedReloadDataSource<SectionModel<String, Double>>()
	
	override func viewDidLoad() {
		super.viewDidLoad()
		
		let dataSource = self.dataSource
		
		let items = Observable.just([
			SectionModel(model: "First section", items: [
						1.0,
						2.0,
						3.0
				]),
			SectionModel(model: "Second section", items: [
						1.0,
						2.0,
						3.0
				]),
			SectionModel(model: "Third section", items: [
						1.0,
						2.0,
						3.0
				])
			])
		
		dataSource.configureCell = { (_, tv, indexPath, element) in
			let cell = tv.dequeueReusableCellWithIdentifier("Cell")!
			cell.textLabel?.text = "\(element) @ row \(indexPath.row)"
			return cell
		}
		
		items
			.bindTo(tableView.rx_itemsWithDataSource(dataSource))
			.addDisposableTo(disposeBag)
		
		tableView
			.rx_itemSelected
			.map { indexPath in
				//转换成dataSource里的item
				return (indexPath, dataSource.itemAtIndexPath(indexPath))
		}
			.subscribeNext { indexPath, model in
				DefaultWireframe.presentAlert("Tapped `\(model)` @ \(indexPath)")
		}
		.addDisposableTo(disposeBag)
		
		tableView
			.rx_setDelegate(self)
			.addDisposableTo(disposeBag)
	}
	
	func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
		let label = UILabel(frame: CGRect.zero)
		label.text = dataSource.sectionAtIndex(section).model ?? ""
		return label
	}
	
}
