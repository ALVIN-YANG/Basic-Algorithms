//
//  UIImagePickerController+RxCreate.swift
//  8.ImagePicker
//
//  Created by 杨卢青 on 16/8/18.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import Foundation
import UIKit
import RxSwift
import RxCocoa

func dismissViewController(viewController: UIViewController, animated: Bool) {
	if viewController.isBeingDismissed() || viewController.isBeingPresented() {
		// 到主线程操作?
		dispatch_async(dispatch_get_main_queue()) {
			dismissViewController(viewController, animated: animated)
		}
		return
	}
	if viewController.presentingViewController != nil {
		viewController.dismissViewControllerAnimated(animated, completion: nil)
	}
}

extension UIImagePickerController {
	
	static func rx_createWithParent(
				parent: UIViewController?,
				animated: Bool = true,
				configureImagePicker: (UIImagePickerController)
				throws -> () = { x in }
				) ->
				Observable<UIImagePickerController> {
					
		return Observable.create { [weak parent] observer in
			
			
			let imagePicker = UIImagePickerController()
			
			let dismissDisposable = imagePicker
				// what? rx_didCancel
					.rx_didCancel
				.subscribeNext ({ [weak imagePicker] in
					guard let imagePicker = imagePicker else {
						return
					}
					dismissViewController(imagePicker, animated: animated)
			})
			
			//error
			do {
				try configureImagePicker(imagePicker)
			}
			catch let error {
				observer.on(.Error(error))
				// what ? 直接内存回收吗?
				return NopDisposable.instance
			}
			
			//已经完成, 可能吗?... 还没渲染完?
			guard let parent = parent else {
				observer.on(.Completed)
				return NopDisposable.instance
			}
			
			//打开系统图片选择
			parent.presentViewController(imagePicker, animated: animated, completion: nil)
			observer.on(.Next(imagePicker))
			
			// what? CompositeDisposable
			return CompositeDisposable(dismissDisposable, AnonymousDisposable{
					dismissViewController(imagePicker, animated: animated)
				})
		}
	}
}
