//
//  ImagePickerController.swift
//  8.ImagePicker
//
//  Created by 杨卢青 on 16/8/17.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import Foundation
import UIKit
import RxSwift
import RxCocoa

class ImagePickerController: UIViewController {
	@IBOutlet weak var imageView: UIImageView!

	@IBOutlet weak var cameraButton: UIButton!
	
	@IBOutlet weak var galleryButton: UIButton!
	
	@IBOutlet weak var cropButton: UIButton!
	
	let disposeBag = DisposeBag()
	
	override func viewDidLoad() {
		super.viewDidLoad()
		
		cameraButton.enabled = UIImagePickerController.isSourceTypeAvailable(.Camera)
		
		cameraButton.rx_tap
			.flatMapLatest { [ weak self] _ in
				return UIImagePickerController
							.rx_createWithParent(self) { picker in
								picker.sourceType = .Camera
								picker.allowsEditing = false
				}
					.flatMap { $0.rx_didFinishPickingMediaWithInfo }
					.take(1)
		}
			.map { info in
				return info[UIImagePickerControllerOriginalImage] as? UIImage
		}
		.bindTo(imageView.rx_image)
		.addDisposableTo(disposeBag)
		
		galleryButton.rx_tap
			//flatMapLatest 把tap的动作转换成序列
			.flatMapLatest { [weak self] _ in
				
				return
					UIImagePickerController
						.rx_createWithParent(self) {
						picker in
							picker.sourceType = .PhotoLibrary
							picker.allowsEditing = false
						}
						.flatMap {
							$0.rx_didFinishPickingMediaWithInfo
						}
						.take(1)
			}
			.map { info in
				return info[UIImagePickerControllerOriginalImage] as? UIImage
		}
		.bindTo(imageView.rx_image)
		.addDisposableTo(disposeBag)
		
		cropButton.rx_tap
			.flatMapLatest { [weak self] _ in
				return UIImagePickerController.rx_createWithParent(self) {
					picker in
						picker.sourceType = .PhotoLibrary
						picker.allowsEditing = true
				}
					.flatMap { $0.rx_didFinishPickingMediaWithInfo }
					.take(1)
		}
			.map { info in
				return info[UIImagePickerControllerEditedImage] as? UIImage
		}
		.bindTo(imageView.rx_image)
		.addDisposableTo(disposeBag)
	}
	
}
