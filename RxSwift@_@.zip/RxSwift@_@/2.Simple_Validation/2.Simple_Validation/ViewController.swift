//
//  ViewController.swift
//  2.Simple_Validation
//
//  Created by 杨卢青 on 16/8/8.
//  Copyright © 2016年 杨卢青. All rights reserved.
//

import Foundation
import UIKit
import RxSwift
import RxCocoa

let minimalUsernameLength = 5
let minimalPasswordLength = 5

class ViewController: UIViewController {

  @IBOutlet weak var userNameTextField: UITextField!

  @IBOutlet weak var usernameValidLabel: UILabel!

  @IBOutlet weak var passwordTextField: UITextField!

  @IBOutlet weak var passwordValidLabel: UILabel!

  @IBOutlet weak var doSomethingButton: UIButton!

  let disposeBag = DisposeBag()

  override func viewDidLoad() {
    super.viewDidLoad()

    usernameValidLabel.text = "UserName has to be at least \(minimalUsernameLength) characters"
    passwordValidLabel.text = "Password has to be at least \(minimalPasswordLength) characters"

    let usernameValid = userNameTextField.rx_text
      .map { $0.characters.count >= minimalUsernameLength }

      .shareReplay(1) // 如果没有他, 每次绑定都会执行一次

    let passwordValid = passwordTextField.rx_text
      .map { $0.characters.count >= minimalPasswordLength }
      .shareReplay(1)

    let everythingValid = Observable.combineLatest(usernameValid, passwordValid) { $0 && $1 }
      .shareReplay(1)

    usernameValid
      .bindTo(passwordTextField.rx_enabled)
      .addDisposableTo(disposeBag)
    usernameValid
      .bindTo(usernameValidLabel.rx_hidden)
      .addDisposableTo(disposeBag)
    passwordValid
      .bindTo(passwordValidLabel.rx_hidden)
      .addDisposableTo(disposeBag)
    everythingValid
      .subscribeNext({ (enabled) in
        self.doSomethingButton.enabled = enabled
        if enabled.boolValue == true {
          self.doSomethingButton.backgroundColor = UIColor.orangeColor()
        }
        else {
          self.doSomethingButton.backgroundColor = UIColor.lightGrayColor()
        }
    })
      .addDisposableTo(disposeBag)

    doSomethingButton.rx_tap
      .subscribeNext { [weak self] in
        self?.showAlert()
    }
      .addDisposableTo(disposeBag)
  }

  func showAlert() {
    let alertView = UIAlertView(
      title: "RxExample",
      message: "This is wonderful",
      delegate: nil,
      cancelButtonTitle: "OK"
    )

    alertView.show()
  }

}

