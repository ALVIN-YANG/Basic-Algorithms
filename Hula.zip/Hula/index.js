//noinspection JSUnresolvedFunction
/**
 * Created by 青椒 on 16/9/1.
 */
function Pet(word) {
    this.word = word;
    this.speak = function (word) {
        console.log(this.word);
    };
}

function Dog(word) {
    Pet.call(this, word)
}

var dog = new Dog('wang');
dog.speak();